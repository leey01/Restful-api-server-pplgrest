<?php 

class Siswa_model extends CI_Model 
{
    public function getSiswa($id = null) {
        if ($id === null) {
            return $this->db->get('pplg1')->result_array();
        } else {
            return $this->db->get_where('pplg1', ['id' => $id])->result_array();
        }
    }
}